<?php

namespace Drupal\Dbexport;

/**
 * Provides an interface defining a sos manager.
 */
interface DbexportManagerInterface {

  /**
   *
   * return selectcase route function.
   *   
   */
  public function DbExport();


}
